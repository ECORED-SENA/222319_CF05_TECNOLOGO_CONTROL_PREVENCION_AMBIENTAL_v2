function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6eEUhL7HK4N":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

